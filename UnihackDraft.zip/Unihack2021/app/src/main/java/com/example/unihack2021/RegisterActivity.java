package com.example.unihack2021;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    EditText username,mail,passwordRegister,passwordConfirmation;
    FirebaseAuth firebaseAuth;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        username=findViewById(R.id.username);
        mail=findViewById(R.id.mailRegister);
        passwordRegister=findViewById(R.id.passwordRegister);
        passwordConfirmation=findViewById(R.id.passwordConfirmation);
        firebaseAuth=FirebaseAuth.getInstance();
        register=findViewById(R.id.registerButton);
        if(firebaseAuth.getCurrentUser()!=null){
            startActivity(new Intent(RegisterActivity.this,UserMain.class));
            finish();
        }
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString().trim();
                String email = mail.getText().toString().trim();
                String password = passwordRegister.getText().toString().trim();
                String passwordConfirm = passwordConfirmation.getText().toString().trim();
                if(TextUtils.isEmpty(user)){
                    username.setError("Username is required!");
                    return;
                }
                if (TextUtils.isEmpty(email)){
                    mail.setError("Mail is required!");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    passwordRegister.setError("Password is required!");
                    return;
                }
                if(TextUtils.isEmpty(passwordConfirm)){
                    passwordConfirmation.setError("Password confirmation is required!");
                    return;
                }
                if(password.length()<6){
                    passwordRegister.setError("Password must be longer than 6 characters!");
                }

                firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(RegisterActivity.this,"The user was created!",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this,UserMain.class));
                            finish();
                        }else{
                            Toast.makeText(RegisterActivity.this,"Error!"+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}