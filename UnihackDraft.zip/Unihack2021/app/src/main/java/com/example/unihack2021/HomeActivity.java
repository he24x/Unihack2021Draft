package com.example.unihack2021;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {
    TextView register,passwordReset;
    EditText mail,passwordLogin;
    Button login;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mail=findViewById(R.id.mailLogin);
        passwordLogin=findViewById(R.id.passwordLogin);
        login=findViewById(R.id.button);
        firebaseAuth=FirebaseAuth.getInstance();
        register=findViewById(R.id.textRegister);
        if(firebaseAuth.getCurrentUser()!=null){
            startActivity(new Intent(HomeActivity.this,UserMain.class));
            finish();
        }
        register.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, RegisterActivity.class);
                Bundle bundle = ActivityOptions.makeSceneTransitionAnimation(HomeActivity.this).toBundle();
                startActivity(intent, bundle);
            }
        });
        passwordReset=findViewById(R.id.textReset);
        passwordReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, RegisterActivity.class);
                Bundle bundle = ActivityOptions.makeSceneTransitionAnimation(HomeActivity.this).toBundle();
                finish();
                startActivity(intent, bundle);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = mail.getText().toString().trim();
                String password= passwordLogin.getText().toString().trim();
                firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(HomeActivity.this,"Login is succesful!",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(HomeActivity.this,HomeActivity.class));
                            finish();
                        }else{
                            Toast.makeText(HomeActivity.this,"Error !"+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}